import json
from llm_client import get_schema_mapping
from query_builder import QueryBuilder
from computed_field_resolver import resolve,get_all_columns
import os

def load_schema(path):
    try:
        with open(path) as f:
            return json.load(f)
    except Exception as e:
        print(f"❌ Failed to load schema from {path}: {e}")
        return {}

def load_query(path):
    try:
        with open(path) as f:
            return f.read()
    except Exception as e:
        print(f"❌ Failed to load query from {path}: {e}")
        return ""

def normalize_mapping(raw_mapping, default_table="contracts"):
    normalized = {}
    skipped_fields = []

    for key, value in raw_mapping.items():
        if isinstance(value, str):
            if value.lower().startswith("missing") or "field is missing" in value.lower() or "not available" in value.lower():
                print(f"⚠️ Skipping unmapped field: {key} → {value}")
                skipped_fields.append(key)
                continue
            normalized[key] = value if "." in value else f"{default_table}.{value}"

        elif isinstance(value, dict):
            table = value.get("table")
            column = value.get("column")
            if table and column:
                normalized[key] = f"{table}.{column}"
            else:
                print(f"⚠️ Skipping unmapped field: {key} → {value}")
                skipped_fields.append(key)

        else:
            print(f"⚠️ Unexpected mapping format for: {key} → {value}")
            skipped_fields.append(key)  # ✅ This was missing

    return normalized, skipped_fields



def normalize_joins(raw_joins):
    normalized = []

    for join in raw_joins:
        # Handle nested 'on' format: list of dicts
        if isinstance(join.get("on"), list):
            for pair in join["on"]:
                for left, right in pair.items():
                    left_table, left_column = left.split(".")
                    right_table, right_column = right.split(".")
                    normalized.append({
                        "from_table": left_table,
                        "to_table": right_table,
                        "from_column": left_column,
                        "to_column": right_column
                    })
        else:
            # Handle flat format
            from_table = join.get("from_table") or join.get("left_table")
            to_table = join.get("to_table") or join.get("right_table")
            from_column = join.get("from_column")
            to_column = join.get("to_column")

            # If 'on' is used instead of explicit columns
            if not from_column or not to_column:
                on = join.get("on")
                if isinstance(on, str) and "." in on:
                    parts = on.split(".")
                    from_column = parts[-1]
                    from_table = parts[0] if not from_table else from_table
                    to_column = parts[-1]
                    to_table = parts[0] if not to_table else to_table

            if from_table and to_table and from_column and to_column:
                normalized.append({
                    "from_table": from_table,
                    "to_table": to_table,
                    "from_column": from_column,
                    "to_column": to_column
                })
            else:
                print(f"⚠️ Skipping malformed join: {join}")

    return normalized

def report_coverage(customer, canonical_fields, valid_fields, computed_fields_raw, missing_fields,fallback_fields):
    # Normalize computed_fields
    computed_fields = {}
    if isinstance(computed_fields_raw, dict):
        computed_fields = computed_fields_raw
    elif isinstance(computed_fields_raw, list):
        computed_fields = {field: "Computed" for field in computed_fields_raw}
    else:
        print(f"⚠️ Unexpected format for computed_fields: {computed_fields_raw}")

    mapped = set(valid_fields.keys()) - fallback_fields
    computed = set(computed_fields.keys())
    total = set(canonical_fields)

    covered = mapped.union(computed)
    missing = set(missing_fields)
    print(f"\n📊 Coverage Report for {customer}:")
    print(f"✅ Mapped fields: {sorted(mapped)}")
    print(f"🧠 Computed fields: {sorted(computed)}")
    print(f"❌ Missing fields: {sorted(missing)}")
    print(f"📈 Coverage: {len(covered)}/{len(canonical_fields)} fields\n")


def main():
    canonical_fields = ["contract_id", "contract_status", "renewal_date", "contract_value"]
    canonical_query = load_query("canonical_query.sql")

    schema_dir = "schemas"
    customer_files = sorted([f for f in os.listdir(schema_dir) if f.endswith(".json")])

    for filename in customer_files:
        customer = filename.replace(".json", "")
        print(f"\n🔍 Translating for {customer}")
        schema = load_schema(os.path.join(schema_dir, filename))
 
        if not schema or "tables" not in schema:
            print(f"❌ Invalid or missing schema for {customer}. Skipping.")
            continue

        response = get_schema_mapping(schema, canonical_fields)
        if not response or "mappings" not in response:
            print("❌ No valid mapping returned. Skipping.")
            continue

        raw_mapping = response.get("mappings", {})
        raw_joins = response.get("joins", [])
        joins = normalize_joins(raw_joins)
        default_table = joins[0]["from_table"] if joins else "contracts"
        mapping ,skipped_fields = normalize_mapping(raw_mapping, default_table)



       # Normalize and resolve computed fields
        computed_fields_raw = response.get("computed_fields", {})
        if "renewal_date" not in computed_fields_raw and "days_remaining" in get_all_columns(schema):
            print("🧠 Injecting fallback hint for renewal_date")
            computed_fields_raw["renewal_date"] = "based on days_remaining"

        if "contract_status" not in computed_fields_raw and "days_remaining" in get_all_columns(schema):
            print("🧠 Injecting fallback hint for contract_status")
            computed_fields_raw["contract_status"] = "based on days_remaining"
        normalized_computed = {}

        if isinstance(computed_fields_raw, dict):
            for field, hint in computed_fields_raw.items():
                expr = resolve(field, hint, schema)
                normalized_computed[field] = expr if expr else None
        elif isinstance(computed_fields_raw, list):
            for field in computed_fields_raw:
                expr = resolve(field, "Computed", schema)
                normalized_computed[field] = expr if expr else None
        else:
            print(f"⚠️ Unexpected format for computed_fields: {computed_fields_raw}")

        # Final computed_fields dict
       # Final computed_fields dict (only include resolved expressions)
        computed_fields = {
            field: expr
            for field, expr in normalized_computed.items()
            if expr is not None
        }



        # Track missing fields
        missing_fields = [field for field in canonical_fields if field not in mapping and field not in computed_fields  and field in skipped_fields]



        if missing_fields:
            print(f"⚠️ Missing fields for {customer}: {missing_fields}")

        builder = QueryBuilder(schema, mapping, joins, computed_fields)

        # Optional: inject fallback NULLs for missing fields
        for field in missing_fields:
            builder.add_fallback_field(field)

        # Add WHERE clause
        """builder.add_where_condition("renewal_date", "<", "'2025-12-31'")"""
        if not builder.add_where_condition("renewal_date", "<", "'2025-12-31'"):
            print("⚠️ Cannot add WHERE condition: renewal_date not mapped or invalid.")
            builder.add_raw_where("1=1")  # Fallback to keep query valid



        # Guard against empty valid fields
        if not builder.valid_fields:
            print(f"❌ No valid fields for {customer}. Skipping query generation.")
            continue

        translated_query = builder.build_query()
        print(f"✅ Translated Query:\n{translated_query}")

        report_coverage(customer, canonical_fields, builder.valid_fields, computed_fields,missing_fields,builder.fallback_fields)

if __name__ == "__main__":
    main()
