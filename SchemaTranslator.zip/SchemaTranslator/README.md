# Schema Translator

This tool bridges diverse customer schemas using LLM-powered semantic mapping.

## Features
- Ingests JSON-based schema definitions
- Uses GPT-4 to map canonical fields to tenant-specific schema
- Translates standardized SQL queries dynamically

## How It Works
1. Load schema and canonical query
2. Use LLM to generate field mappings
3. Translate query using those mappings

## Requirements
- Python 3.8+
- `openai` Python SDK
