SELECT contract_id, contract_status, renewal_date, contract_value
FROM contracts
WHERE renewal_date < '2025-12-31'