from openai import OpenAI

#client = OpenAI(api_key="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")
import os
import re
import json
from openai import OpenAI
from dotenv import load_dotenv
load_dotenv()
# Use environment variable for security
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def get_schema_mapping(schema_json, canonical_fields):
    prompt = f"""
You are a schema-aware data engineer. Given the following schema and canonical fields, return a structured JSON with:

- "mappings": canonical → actual field (either string or {{ "table": ..., "column": ... }})
- "joins": list of join relationships using keys: "from_table", "to_table", "on"
- "computed_fields": dictionary of computed field hints for any canonical field that is not directly mappable but can be derived from available fields (e.g., 'contract_status' from 'days_remaining')

Canonical fields:
{canonical_fields}

Schema:
{json.dumps(schema_json, indent=2)}

Instructions:
- If a field is missing, clearly state "Missing field" or "Field not available"
- If a field is not directly available but can be computed from existing fields, include it in 'computed_fields' with a brief hint
- Avoid hallucinating tables or columns not present in the schema
- Do not include markdown, explanations, or formatting
- Respond with a single valid JSON object only
"""



    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2
        )
        raw_content = response.choices[0].message.content
        print("🔎 Raw LLM response:\n", raw_content)
        # Log structure confidence
        if '"mappings"' not in raw_content:
            print("⚠️ Warning: 'mappings' key missing in LLM response.")
        if '"joins"' not in raw_content:
            print("⚠️ Warning: 'joins' key missing in LLM response.")
        return extract_valid_json(raw_content)
    except Exception as e:
        print("❌ LLM call failed:", e)
        return {}

def extract_valid_json(text):
    try:
        parsed = json.loads(text)
        if is_valid_mapping(parsed):
            return parsed
    except:
        pass

    match = re.search(r"```json\s*(\{.*?\})\s*```", text, re.DOTALL)
    if not match:
        match = re.search(r"(\{.*?\})", text, re.DOTALL)

    if match:
        try:
            cleaned = match.group(1).strip()
            parsed = json.loads(cleaned)
            if is_valid_mapping(parsed):
                return parsed
        except json.JSONDecodeError as e:
            print("❌ JSON parsing failed:", e)
    else:
        print("❌ No JSON block found in LLM response.")
    return {}

def is_valid_mapping(response):
    return (
        isinstance(response, dict) and
        "mappings" in response and
        isinstance(response["mappings"], dict) and
        "joins" in response and
        isinstance(response["joins"], list)
    )

