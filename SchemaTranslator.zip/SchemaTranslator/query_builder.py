class QueryBuilder:
    def __init__(self, schema, mapping, joins=None,computed_fields = None):
        self.schema = schema
        self.mapping = mapping
        self.joins = joins or []
        self.computed_fields = computed_fields or {}
        self.valid_fields = self._validate_mapping()
        self.fallback_fields = set()
        self.where_conditions = []

    def add_fallback_field(self, field):
        self.valid_fields[field] = f"NULL AS {field}"
        self.fallback_fields.add(field)

    
    def _validate_mapping(self):
        valid = {}
        for canonical, actual in self.mapping.items():
            if isinstance(actual, str) and "." in actual:
                table, column = actual.split(".")
                if table in self.schema["tables"] and column in self.schema["tables"][table]["columns"]:
                    valid[canonical] = actual
                else:
                    print(f"⚠️ Field {actual} not found in schema.")
            else:
                print(f"⚠️ Skipping unmapped field: {canonical} → {actual}")
        return valid

    def add_where_condition(self, canonical_field, operator, value):
        actual_field = self.valid_fields.get(canonical_field)

        # Skip if it's a fallback (starts with NULL AS ...)
        if actual_field and actual_field.startswith("NULL AS"):
            print(f"⚠️ Skipping WHERE condition for fallback field: {canonical_field}")
            return False

        if actual_field:
            self.where_conditions.append(f"{actual_field} {operator} {value}")
            return True
        else:
            print(f"⚠️ Cannot add WHERE condition: {canonical_field} not mapped or invalid.")
            return False

    def add_raw_where(self, clause):
    
         self.where_conditions.append(clause)


    def build_select_clause(self):
        select_parts = []

        # Include validated mapped fields
        for canonical in self.valid_fields:
            select_parts.append(self.valid_fields[canonical])

        # Include computed fields
        for field, expression in self.computed_fields.items():
            if isinstance(expression, str):
                expr_lower = expression.lower()

                # If already aliased, use directly
                if " as " in expr_lower:
                    select_parts.append(expression)
                # If vague hint, fallback to NULL
                elif any(keyword in expr_lower for keyword in ["computed", "derived", "external", "missing"]):
                    select_parts.append(f"NULL AS {field}")
                else:
                    select_parts.append(f"{expression} AS {field}")
            else:
                select_parts.append(f"NULL AS {field}")

        return "SELECT " + ", ".join(select_parts)



        

    def build_from_clause(self):
        if not self.joins:
            first_table = next(iter(self.valid_fields.values())).split(".")[0]
            return f"FROM {first_table}"

        base_table = self.joins[0]["from_table"]
        clause = f"FROM {base_table}\n"
        for join in self.joins:
            if "from_table" in join and "to_table" in join:
                from_col = join.get("from_column") or join.get("on")
                to_col = join.get("to_column") or join.get("on")
                if from_col and to_col:
                    clause += (
                        f"LEFT JOIN {join['to_table']} ON "
                        f"{join['from_table']}.{from_col} = {join['to_table']}.{to_col}\n"
                    )
                else:
                    print(f"⚠️ Skipping join due to missing column info: {join}")
            else:
                print(f"⚠️ Skipping malformed join: {join}")
        return clause.strip()

    def build_where_clause(self):
        if not self.where_conditions:
            return "WHERE 1=1"
        return "WHERE " + " AND ".join(self.where_conditions)


    def build_query(self):
        return "\n".join([
            self.build_select_clause(),
            self.build_from_clause(),
            self.build_where_clause()
        ])
