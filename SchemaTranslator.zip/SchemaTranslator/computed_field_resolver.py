def get_all_columns(schema):
    """
    Extracts all column names from all tables in the schema.
    Returns a set of column names.
    """
    columns = set()
    for table_def in schema.get("tables", {}).values():
        columns.update(table_def.get("columns", []))
    return columns

def resolve(field_name, hint, schema):
    if isinstance(hint, dict):
        hint = hint.get("hint", "")
    if not isinstance(hint, str):
        print(f"⚠️ Invalid hint format for {field_name}: {hint}")
        return None

    hint_lower = hint.lower()
    columns = {col.lower() for col in get_all_columns(schema)}

    remaining_terms = ["days_remaining", "remaining", "remaining_days"]

    if field_name.lower() == "contract_status":
        for term in remaining_terms:
            if term in hint_lower and term in columns:
                return (
                    "CASE "
                    f"WHEN {term} > 90 THEN 'Active' "
                    f"WHEN {term} BETWEEN 31 AND 90 THEN 'Expiring Soon' "
                    f"WHEN {term} BETWEEN 1 AND 30 THEN 'Urgent' "
                    f"ELSE 'Expired' END"
                )

    if field_name.lower() == "renewal_date":
        for term in remaining_terms:
            if term in hint_lower and term in columns:
                return f"CURRENT_DATE + INTERVAL {term} DAY"

    print(f"⚠️ Could not resolve {field_name} → {hint}")
    return None
